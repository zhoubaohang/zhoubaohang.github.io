package com.zbh.iotapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Created by 周宝航 on 2017/9/30.
 */

public class NetSettingsDialog implements View.OnClickListener {


    private static final String SPNAME = "remotesettings";
    private static final String SP_IP = "serverip";
    private static final String SP_PORT = "serverport";
    private static final String SP_FIRSTTIME = "firsttime";

    private Context context;
    private LayoutInflater layoutInflater;
    private AlertDialog.Builder builder;
    private AlertDialog dialog;

    private Button btn_conform, btn_cancel;
    private EditText et_remoteip, et_remtoeport;

    public NetSettingsDialog(Context context, LayoutInflater layoutInflater) {
        this.context = context;
        this.layoutInflater = layoutInflater;
        initView();
    }

    public void show() {
        dialog.show();
        getRemoteNetSettings();
    }

    public void close() {
        dialog.dismiss();
    }

    private void initView() {
        builder = new AlertDialog.Builder(this.context);
        builder.setTitle(R.string.activity_login_title);
        LinearLayout viewLayout = (LinearLayout) layoutInflater.inflate(R.layout.dialog_netsettings, null);
        btn_cancel = (Button) viewLayout.findViewById(R.id.activity_login_btn_cancel);
        btn_conform = (Button) viewLayout.findViewById(R.id.activity_login_btn_confirm);
        et_remoteip = (EditText) viewLayout.findViewById(R.id.activity_login_et_remoteip);
        et_remtoeport = (EditText) viewLayout.findViewById(R.id.activity_login_et_remoteport);

        btn_conform.setOnClickListener(this);
        btn_cancel.setOnClickListener(this);
        builder.setView(viewLayout);
        dialog = builder.create();
    }

    private void getRemoteNetSettings() {
        SharedPreferences sp = this.context.getSharedPreferences(SPNAME, Context.MODE_PRIVATE);
        String remoteip = sp.getString(SP_IP, "");
        int remoteport = sp.getInt(SP_PORT, 0);
        et_remoteip.setText(remoteip);
        et_remtoeport.setText(String.valueOf(remoteport));
    }

    private void saveSettings() {
        String remoteip = et_remoteip.getText().toString();
        String remoteport = et_remtoeport.getText().toString();
        if (remoteip.equals("") == false && remoteport.equals("") == false) {
            SharedPreferences sp = this.context.getSharedPreferences(SPNAME, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sp.edit();
            editor.putString(SP_IP, remoteip);
            editor.putInt(SP_PORT, Integer.parseInt(remoteport));
            editor.putBoolean(SP_FIRSTTIME, true);
            editor.commit();
        }
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.activity_login_btn_cancel:
                this.close();
                break;
            case R.id.activity_login_btn_confirm:
                saveSettings();
                MainActivity activity = (MainActivity) this.context;
                activity.updateConfig();
                this.close();
                break;
        }
    }
}
