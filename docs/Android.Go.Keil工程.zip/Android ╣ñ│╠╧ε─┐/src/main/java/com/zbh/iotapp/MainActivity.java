package com.zbh.iotapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import lecho.lib.hellocharts.view.LineChartView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    LineChartView lineChartView;
    TextView tv_temp;
    Button btn_light;

    private LineChartManager lineChartManager;
    private WebRequest webRequest;
    private RequestHandler handler;
    private LightControl lightControl;
    private boolean light_flag = false;
    private NetSettingsDialog netSettingsDialog;

    private static final String SPNAME = "remotesettings";
    private static final String SP_IP = "serverip";
    private static final String SP_PORT = "serverport";
    private static final String SP_FIRSTTIME = "firsttime";

    private String ip;
    private int port;
    private boolean firsttime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initConfig();
        initView();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_activity, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_netsettings:
                netSettingsDialog.show();
                break;
        }
        return true;
    }

    private void initConfig() {
        SharedPreferences sp = this.getSharedPreferences(SPNAME, Context.MODE_PRIVATE);
        this.ip = sp.getString(SP_IP, "");
        this.port = sp.getInt(SP_PORT, 0);
        this.firsttime = sp.getBoolean(SP_FIRSTTIME, false);
    }

    public void updateConfig() {
        initConfig();
        webRequest.Stop();
        webRequest.UpdateSettings(this.ip, this.port);
        webRequest.Start();
        new Thread(webRequest).start();

        lightControl.UpdateSettings(this.ip, this.port);
    }


    private void initView() {
        tv_temp = (TextView) findViewById(R.id.tv_temp);
        lineChartView = (LineChartView) findViewById(R.id.linechar_temp);
        lineChartManager = new LineChartManager(lineChartView);
        lineChartManager.showMovingLineChart();
        handler = new RequestHandler(tv_temp, lineChartManager);
        webRequest = new WebRequest(handler, this.ip, this.port);

        lightControl = new LightControl(this.ip, this.port);
        btn_light = (Button) findViewById(R.id.btn_light);
        btn_light.setOnClickListener(this);
        if (!light_flag) {
            btn_light.setText("开灯");
        } else {
            btn_light.setText("关灯");
        }

        netSettingsDialog = new NetSettingsDialog(MainActivity.this, this.getLayoutInflater());

        if (!this.firsttime) {
            netSettingsDialog.show();
        } else {
            new Thread(webRequest).start();
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_light:
                if (!light_flag) {
                    btn_light.setText("关灯");
                    light_flag = true;
                    lightControl.openLight();
                } else {
                    btn_light.setText("开灯");
                    light_flag = false;
                    lightControl.closeLight();
                }
                break;
        }
    }
}
