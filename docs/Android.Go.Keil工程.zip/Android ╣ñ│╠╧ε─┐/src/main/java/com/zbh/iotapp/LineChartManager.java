package com.zbh.iotapp;

import android.graphics.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import lecho.lib.hellocharts.gesture.ContainerScrollType;
import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.AxisValue;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.model.ValueShape;
import lecho.lib.hellocharts.model.Viewport;
import lecho.lib.hellocharts.view.LineChartView;

/**
 * Created by 周宝航 on 2017/9/28.
 */

public class LineChartManager {

    private LineChartView lineChartView;
    private ArrayList<PointValue> pointValues;
    private ArrayList<Line> lines;
    private ArrayList<PointValue> points;
    private Axis axisX, axisY;
    private LineChartData lineChartData;
    private Timer timer;

    private List<AxisValue> mAxisXValues;

    public LineChartManager(LineChartView lineChartView) {
        this.lineChartView = lineChartView;
        initAxisView();
    }

    private void initAxisView() {
        pointValues = new ArrayList<PointValue>();
        lines = new ArrayList<Line>();
        points = new ArrayList<PointValue>();

        /** 初始化Y轴 */
        axisY = new Axis();
        axisY.setName("温度（单位：摄氏度）");//添加Y轴的名称
        axisY.setHasLines(true);//Y轴分割线
        axisY.setTextSize(10);//设置字体大小
//        axisY.setTextColor(Color.parseColor("#AFEEEE"));//设置Y轴颜色，默认浅灰色
        lineChartData = new LineChartData(lines);
        lineChartData.setAxisYLeft(axisY);//设置Y轴在左边

        /** 初始化X轴 */
        axisX = new Axis();
        axisX.setHasTiltedLabels(false);//X坐标轴字体是斜的显示还是直的，true是斜的显示
//        axisX.setTextColor(Color.CYAN);//设置X轴颜色
        axisX.setName("时间（单位：s）");//X轴名称
        axisX.setHasLines(true);//X轴分割线
        axisX.setTextSize(10);//设置字体大小
        axisX.setMaxLabelChars(1);//设置0的话X轴坐标值就间隔为1
        mAxisXValues = new ArrayList<AxisValue>();
        for (int i = 0; i < 11; i++) {
            mAxisXValues.add(new AxisValue(i).setLabel(i + ""));
        }
        axisX.setValues(mAxisXValues);//填充X轴的坐标名称
        lineChartData.setAxisXBottom(axisX);//X轴在底部

        lineChartView.setLineChartData(lineChartData);

        Viewport port = initViewPort(0, 10);//初始化X轴10个间隔坐标
        lineChartView.setCurrentViewportWithAnimation(port);
        lineChartView.setInteractive(false);//设置不可交互
        lineChartView.setScrollEnabled(true);
        lineChartView.setValueTouchEnabled(false);
        lineChartView.setFocusableInTouchMode(false);
        lineChartView.setViewportCalculationEnabled(false);
        lineChartView.setContainerScrollEnabled(true, ContainerScrollType.HORIZONTAL);
        lineChartView.startDataAnimation();
    }

    private Viewport initViewPort(float left, float right) {
        Viewport port = new Viewport();
        port.top = 50;//Y轴上限，固定(不固定上下限的话，Y轴坐标值可自适应变化)
        port.bottom = 10;//Y轴下限，固定
        port.left = left;//X轴左边界，变化
        port.right = right;//X轴右边界，变化
        return port;
    }

    public void addData(float temp) {
        points.add(new PointValue(pointValues.size() + 1, temp));
    }

    public void showMovingLineChart() {

        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                PointValue TmpPoint = null;
                if (points.size() > 0) {
                    TmpPoint = points.remove(0);
                    pointValues.add(TmpPoint);//实时添加新的点
                    if (pointValues.size() > 9) {
                        mAxisXValues.remove(0);
                        mAxisXValues.add(new AxisValue(pointValues.size()+1).setLabel(pointValues.size()+1+""));
                    }
                }

                //根据新的点的集合画出新的线
                Line line = new Line(pointValues);
                line.setColor(Color.parseColor("#FFCD41"));//设置折线颜色
                line.setShape(ValueShape.CIRCLE);//设置折线图上数据点形状为 圆形 （共有三种 ：ValueShape.SQUARE  ValueShape.CIRCLE  ValueShape.DIAMOND）
                line.setCubic(false);//曲线是否平滑，true是平滑曲线，false是折线
                line.setHasLabels(true);//数据是否有标注
//        line.setHasLabelsOnlyForSelected(true);//点击数据坐标提示数据,设置了line.setHasLabels(true);之后点击无效
                line.setHasLines(true);//是否用线显示，如果为false则没有曲线只有点显示
                line.setHasPoints(true);//是否显示圆点 ，如果为false则没有原点只有点显示（每个数据点都是个大圆点）
                lines.add(line);
                lineChartData = new LineChartData(lines);
                lineChartData.setAxisYLeft(axisY);//设置Y轴在左
                lineChartData.setAxisXBottom(axisX);//X轴在底部
                lineChartView.setLineChartData(lineChartData);

                if (TmpPoint != null) {
                    float xAxisValue = TmpPoint.getX();
                    //根据点的横坐标实时变换X坐标轴的视图范围
                    Viewport port;
                    if (xAxisValue > 10) {
                        port = initViewPort(xAxisValue - 10, xAxisValue);
                    } else {
                        port = initViewPort(0, 10);
                    }
                    lineChartView.setMaximumViewport(port);
                    lineChartView.setCurrentViewport(port);
                }

//                if (pointValues.size() % 61 == 0) {
//                    axisX.setValues(mAxisXValues);//填充X轴的坐标名称
//                }

            }
        }, 1000, 1000);
    }
}
