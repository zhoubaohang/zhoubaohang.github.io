package com.zbh.iotapp;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.io.IOException;


import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by 周宝航 on 2017/9/28.
 */

public class WebRequest implements Runnable {

    private String URL = "http://192.168.1.2:9000/temp";

    private OkHttpClient client;
    private Request request;
    private Call call;
    private RequestHandler handler;

    private boolean RUNNING_FLAG;
    private String ip;
    private int port;

    public WebRequest(RequestHandler handler, String ip, int port) {
        this.client = new OkHttpClient();
        request = new Request.Builder().url(URL).build();
        this.handler = handler;
        Start();
        this.ip = ip;
        this.port = port;
        updateURL();
    }

    private void updateURL() {
        this.URL = String.format("http://%s:%d/temp", ip, port);
        request = new Request.Builder().url(this.URL).build();
    }

    private float getTemp() {
        Response response;
        float temp = 0;
        call = client.newCall(request);
        try {
            response = call.execute();
            temp = Float.valueOf(response.body().string());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return temp;
    }

    public void UpdateSettings(String ip, int port) {
        this.ip = ip;
        this.port = port;
        updateURL();
    }

    public void Start() {
        this.RUNNING_FLAG = true;
    }

    public void Stop() {
        this.RUNNING_FLAG = false;
    }

    @Override
    public void run() {
        while (RUNNING_FLAG) {
            Message msg = new Message();
            msg.what = RequestHandler.TEMP;
            Bundle bundle = new Bundle();
            bundle.putFloat(RequestHandler.MSG_TEMP, this.getTemp());
            msg.setData(bundle);
            this.handler.sendMessage(msg);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


}
