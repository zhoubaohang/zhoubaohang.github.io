package com.zbh.iotapp;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;

/**
 * Created by 周宝航 on 2017/9/29.
 */

public class LightControl {

    private static String URL_OPENLIGHT = "http://192.168.1.2:9000/light/open";
    private static String URL_CLOSELIGHT = "http://192.168.1.2:9000/light/close";

    private LightWebRequest request;

    private String ip;
    private int port;

    public LightControl(String ip, int port) {
        request = new LightWebRequest();
        this.ip = ip;
        this.port = port;
        updateURL();
    }

    private void updateURL() {
        URL_OPENLIGHT = String.format("http://%s:%d/light/open", this.ip, this.port);
        URL_CLOSELIGHT = String.format("http://%s:%d/light/close", this.ip, this.port);
    }

    public void UpdateSettings(String ip, int port) {
        this.ip = ip;
        this.port = port;
        updateURL();
    }

    public void openLight() {
        request.Get(URL_OPENLIGHT);
        new Thread(request).start();
    }

    public void closeLight() {
        request.Get(URL_CLOSELIGHT);
        new Thread(request).start();
    }


    class LightWebRequest implements Runnable {
        private OkHttpClient client;
        private Request request;
        private Call call;

        public LightWebRequest() {
            client = new OkHttpClient();
        }

        public void Get(String url) {
            request = new Request.Builder().url(url).build();
            call = client.newCall(request);
        }

        @Override
        public void run() {
            try {
                call.execute();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
