package com.zbh.iotapp;

import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

import okhttp3.Request;

/**
 * Created by 周宝航 on 2017/9/28.
 */

public class RequestHandler extends Handler {
    public static final String MSG_TEMP = "temp";

    public static final int TEMP = 0;

    private TextView tv_temp;
    private LineChartManager manager;

    public RequestHandler(TextView textView, LineChartManager manager) {
        this.tv_temp = textView;
        this.manager = manager;
    }

    @Override
    public void handleMessage(Message msg) {
        switch (msg.what) {
            case TEMP:
                manager.addData(msg.getData().getFloat(MSG_TEMP));
                this.tv_temp.setText("Current Temperature : " + String.valueOf(msg.getData().getFloat(MSG_TEMP)) + " `C");
                break;
        }
    }
}
