package WebServer

import (
	"CommConnector/CommPort"
	"fmt"
	"log"
	"net/http"
)

type Server struct {
	TempSensor CommPort.TemperatureSensor
	CBCommSend chan string
}

func (s *Server) initConfig() {
	s.CBCommSend = make(chan string)
	s.TempSensor = CommPort.TemperatureSensor{CBSend: s.CBCommSend}
	s.TempSensor.InitSensor()
}

func (s *Server) getTemperature(w http.ResponseWriter, r *http.Request) {
	temp := s.TempSensor.GetTemp()
	if temp != "" {
		fmt.Fprintf(w, temp)
	}
}

func (s *Server) openLight(w http.ResponseWriter, r *http.Request) {
	s.CBCommSend <- "1"
}

func (s *Server) closeLight(w http.ResponseWriter, r *http.Request) {
	s.CBCommSend <- "0"
}

//ListenAndServe : Start the server
func (s *Server) ListenAndServe() {
	s.initConfig()
	http.HandleFunc("/temp", s.getTemperature)
	http.HandleFunc("/light/open", s.openLight)
	http.HandleFunc("/light/close", s.closeLight)
	err := http.ListenAndServe(":9000", nil)
	if err != nil {
		log.Fatal("ListenandServe : ", err)
	}
}
