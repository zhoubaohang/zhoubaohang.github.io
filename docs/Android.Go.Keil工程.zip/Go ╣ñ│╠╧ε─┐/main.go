package main

import
(
	"CommConnector/WebServer"
)

var server WebServer.Server

func initConfig() {
	server = WebServer.Server{}
}

func main() {
	initConfig()
	server.ListenAndServe()
}