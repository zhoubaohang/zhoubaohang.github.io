package CommPort

import 
(
	"github.com/tarm/serial"
	"log"
	"fmt"
)

// Commport : the comm struct for connecting
type Commport struct {
	port *serial.Port
	SPort string
	IBaud int
	CBReceive chan string
	CBSend chan string
	CBQuit chan bool
}

func (comm * Commport) openport() {
	c := &serial.Config{Name:comm.SPort, Baud:comm.IBaud}
	commio, err := serial.OpenPort(c);
	if err != nil {
		log.Fatal("open port error ")
		log.Fatal(err)
	}
	comm.port = commio
}

func (comm * Commport) receive() {
	buf := make([]byte, 128)
	n, err := comm.port.Read(buf)
	if err != nil {
		log.Fatal("receive error ")
		log.Fatal(err)
	}
	if n > 1 {
		//log.Printf(">>>> reveice data size:%d %q", n, buf[:n])
		data := fmt.Sprintf("%d%d.%d%d", buf[0], buf[1], buf[2], buf[3])
		comm.CBReceive <- data
	} else {
		comm.CBReceive <- ""
	}
}

func (comm * Commport) send(data string) {
	_, err := comm.port.Write([]byte(data))
	if err != nil {
		log.Fatal(err)
	}
}

// Listen the comm port and receive the data
func (comm * Commport) Listen() {
	comm.openport()
	if comm.port != nil {
		for {
			select {
			case flag := <- comm.CBQuit:
				if flag {
					break
				} else {
					go comm.receive()
				}
			case data := <- comm.CBSend:
				go comm.send(data)
			}
		}
	}
}