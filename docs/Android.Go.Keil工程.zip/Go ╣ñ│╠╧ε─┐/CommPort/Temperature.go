package CommPort

import (
	"log"
)

const (
	//COMID comm number
	COMID = "COM4"
	//BAUD baud number
	BAUD = 4800
)

//TemperatureSensor : the struct for get the temperature from the comm
type TemperatureSensor struct {
	Comm      Commport
	Temp      string
	CBReceive chan string
	CBSend    chan string
	CBQuit    chan bool
}

//InitSensor : init the config of the comm
func (t *TemperatureSensor) InitSensor() {
	t.CBReceive = make(chan string)
	t.CBQuit = make(chan bool)
	t.Temp = ""
	t.Comm = Commport{SPort: COMID, IBaud: BAUD, CBReceive: t.CBReceive, CBQuit: t.CBQuit, CBSend: t.CBSend}
	go t.Comm.Listen()
	go func(t *TemperatureSensor) {
		for {
			t.Comm.CBQuit <- false
			tmp := <-t.Comm.CBReceive
			if tmp != "" {
				t.Temp = tmp
				log.Printf("%s", t.Temp)
			}
		}
	}(t)
}

//GetTemp : get the temperature in string
func (t *TemperatureSensor) GetTemp() string {
	return t.Temp
}
