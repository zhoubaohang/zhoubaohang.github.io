function [cluster_head, wsn] = FindClusterHead(ex_wsn, wsn, round, P)
    cluster_head = [];
    for j=1:size(wsn,1)
        threshold = CalThreshold(P, round, ~logical(ex_wsn(j, 1)));
        if (rand() < threshold)
            wsn(j,1) = 1;
            cluster_head = [cluster_head ; j];
        end
    end
end