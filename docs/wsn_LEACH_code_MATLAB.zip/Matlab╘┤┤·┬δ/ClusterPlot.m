function [] = ClusterPlot(tmp, tmp_wsn, wsn, cluster_head)
    markSize = 20;
    figure();
    for j=1:size(wsn,1)
        text(wsn(j,1),wsn(j,2),sprintf('%d',j)); hold on;
        head = 0;
        if (logical(size(cluster_head,1)))   % find the distance between this node and cluster head
            distance = sqrt((wsn(cluster_head(:),1)-wsn(j,1)).^2+(wsn(cluster_head(:),2)-wsn(j,2)).^2);
            [val index] = min(distance);
            head = cluster_head(index,1);
        end
        if (logical(head))
            h = plot([wsn(j,1) wsn(head,1)], [wsn(j,2) wsn(head,2)], '.-','markersize',markSize);
            hold on;
        end
        if (tmp(j,1) == 1)                          % ever selected head
            plot(wsn(j,1),wsn(j,2),'rx','markersize',markSize);
        end
        if ((tmp(j,1) == 0) & (tmp_wsn(j,1) == 0))  % normal node
            plot(wsn(j,1),wsn(j,2),'.','markersize',markSize);
        end
        hold on;
    end
    plot(wsn(cluster_head(:,1),1), wsn(cluster_head(:,1),2),'s','markersize',markSize);
end