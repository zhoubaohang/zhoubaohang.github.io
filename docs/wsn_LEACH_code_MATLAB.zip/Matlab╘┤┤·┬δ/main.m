clc;clear();
% the wsn node number
WSN_NODE_NUM = 100;

% cluster head number
CLUSTER_HEAD_NUMBER = 5;

% rounds for selecting head
ROUNDS = WSN_NODE_NUM / CLUSTER_HEAD_NUMBER;

% percentage P
P = CLUSTER_HEAD_NUMBER / WSN_NODE_NUM;

% init the wsn
wsn = InitMatrix(WSN_NODE_NUM, 2);

% tmp wsn for saving cluster head
clustered_wsn = zeros(WSN_NODE_NUM);

% % begin select cluster head
for i=1:5%ROUNDS
    tmp = clustered_wsn;
    [cluster_head, clustered_wsn] = FindClusterHead(tmp, clustered_wsn, i, P);
    ClusterPlot(tmp, clustered_wsn, wsn, cluster_head);
    title(sprintf('%d round', i));
end

% energy number
ENERGY_NUM = 5000;
energy_cache = ones(size(wsn,1),1)*ENERGY_NUM;
rounds = 1;
clustered_wsn = zeros(WSN_NODE_NUM);
while 1
    tmp = clustered_wsn;
    [cluster_head, clustered_wsn] = FindClusterHead(tmp, clustered_wsn, rounds, P);
    if size(cluster_head,1) == 0
        clustered_wsn = zeros(WSN_NODE_NUM);
    end
    while size(cluster_head,1)==0
        tmp = clustered_wsn;
        [cluster_head, clustered_wsn] = FindClusterHead(tmp, clustered_wsn, rounds, P);
    end
    energy_cache = EnergyConsume(clustered_wsn, wsn, cluster_head, energy_cache);
    if min(energy_cache)<=0
        break;
    end
    rounds = rounds + 1;
end
figure();
bar([1:1:size(energy_cache,1)], energy_cache(:));
axis([0 size(energy_cache,1)+1 0 ENERGY_NUM]);
xlabel('node ID');
ylabel('energy');
title(sprintf('the %dth round',rounds));
