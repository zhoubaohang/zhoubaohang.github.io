function [energy] = EnergyConsume(tmp_wsn, wsn, cluster_head, energy)
    clustered_wsn = zeros(size(wsn,1),1);
    times = 10;
    %% Setup %%
    % cluster head broadcast info
    energy(cluster_head(:,1)) = energy(cluster_head(:,1)) - 2;
    % normal node receive info
    energy(tmp_wsn(:,1)~=1) = energy(tmp_wsn(:,1)~=1) - size(cluster_head,1);
    % normal node broadcast
    for i=1:size(wsn,1)
        t = cluster_head(:,1) - i;
        if min(t)==0
            continue;
        end
        distance = sqrt((wsn(cluster_head(:),1)-wsn(i,1)).^2+(wsn(cluster_head(:),2)-wsn(i,2)).^2);
        [val index] = min(distance);
        head = cluster_head(index,1);
        energy(head) = energy(head) - 1;   % cluster head receive info
        energy(i) = energy(i) - 2;      % node send info to head
        clustered_wsn(i) = head;
    end
    %% Steady %%
    for i=1:size(clustered_wsn,1)
        if clustered_wsn(i)==0
            continue;
        end
        for j=1:times
            energy(clustered_wsn(i)) = energy(clustered_wsn(i)) - 1;   % normal node consume energy
            energy(i) = energy(i) - 2;      % cluster head consume energy
        end
    end
end