function [ matrix ] = InitMatrix( rows, cols )
% Init the random wsn
matrix = rand(rows, cols);
end

