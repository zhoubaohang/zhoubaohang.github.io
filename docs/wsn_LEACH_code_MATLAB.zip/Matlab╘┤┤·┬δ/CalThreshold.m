function [ans] = CalThreshold(percentage, round, inGraph)
    if (inGraph)
        ans = percentage/(1-percentage*double(mod(round ,int32(1/percentage))));
    else
        ans = 0;
    end
end