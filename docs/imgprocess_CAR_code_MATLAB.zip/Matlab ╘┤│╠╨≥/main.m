clear();
%Read the image
im = imread('TEST.tif');

%histeq args test
args = [24:10:64];
figure();
subplot(2,3,1);
imshow(im);
title('Original Image');
for i = 1:size(args,2)
    subplot(2,3,i+1);
    imshow(histeq(im, args(1,i)));
    title(sprintf('Grey series %d', args(1,i)));
end

%Grey level transformation
figure();
J = histeq(im);
args = [0.7:0.1:1.1];
subplot(2,3,1);
imshow(J);
title('Original Image');
for i = 1:size(args,2)
    subplot(2,3,i+1);
    imshow(imadjust(J, stretchlim(J), [0 1], args(1,i)));
    title(sprintf('gamma %.1f', args(1,i)));
end

%medfilter compare averagefilter
figure();
g = imadjust(J, stretchlim(J), [0.2 1]);
subplot(1,3,1);
imshow(g);
title('Original Image');
subplot(1,3,2);
imshow(filter2(fspecial('average',3),g)/255);
title('average filter');
subplot(1,3,3);
imshow(medfilt2(g,[3 3]));
title('median filter');
g = medfilt2(g,[3 3]);

% frequency field process
figure();
subplot(1,2,1);
imshow(g);
title('Original Image');
subplot(1,2,2);
fg = imfreqfilt(g, imidealflpf(g, 800));
imshow(fg);
title('Filtered Image');

% binarization
figure();
n = graythresh(fg);
bg = im2bw(fg,n);
imshow(bg);

% negate image
bg = ~bg;

% imclose
t = imdilate(bg,strel('disk',7));
fc = imerode(t,strel('square',8));
imshow(fc);

% get the info
ans = ~bitxor(imfill(~fc,'holes'),fc);
figure();
imshow(ans);

% clear the small noise
rec = regionprops(bwlabel(ans,8),'basic');
figure,imshow(ans);
for i=1:size(rec, 1)
    if (abs(rec(i).BoundingBox(1,1) - size(im,1))>200)
        if (rec(i).BoundingBox(1,3)/rec(i).BoundingBox(1,4) > 1.62)
           rectangle('Position',rec(i).BoundingBox,'FaceColor',[0 0 0]);
        end
    end
end



