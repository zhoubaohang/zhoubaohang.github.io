function [ Pconnect ] = EvalutePconnect(wsn, radio)
    rows = size(wsn,1);
    D = zeros(rows);
    for i = 1:rows
        point1 = wsn(i,:);
        for j = 1:rows
            point2 = wsn(j,:);
            if (point1(1)-point2(1))^2+(point1(2)-point2(2))^2 < radio^2
                D(i,j) = 1;
                D(j,i) = 1;
            end
        end
    end
    matrix_tmp = zeros(rows);
    for i = 1:rows-1
        matrix_tmp = matrix_tmp + D^i;
    end
    for i = 1:rows
       for j = 1:rows
           if i ~= j && matrix_tmp(i,j)==0
               Pconnect = false;
               return
           end
       end
    end
    Pconnect = true;
end

