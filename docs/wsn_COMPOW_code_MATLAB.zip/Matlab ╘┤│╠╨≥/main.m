clear();
wsnNodeNum = 20;
powerLevel = [0.1:0.1:0.5];

% init the wsn matrix
wsnMatrix = InitMatrix(wsnNodeNum, 2);
power = 0;
% find the mininum power level confirming the wsn is connected
for i=1:size(powerLevel, 2)
    if EvalutePconnect(wsnMatrix, powerLevel(i))
        power = i;
        break;
    end
end

% plot the topology map 
coverageRadius = powerLevel(1,power);
figure();
PlotConnectMap(wsnMatrix, coverageRadius);
title(sprintf('power level = %d\n wsn node num = %d', i, wsnNodeNum));
hold on;
for i=1:wsnNodeNum
    PlotCircle(wsnMatrix(i,1),wsnMatrix(i,2),coverageRadius,false);
    plot(wsnMatrix(i,1),wsnMatrix(i,2),'bo','MarkerFaceColor','b');
    axis([0 1 0 1]);
    hold on;
end
title(sprintf('power level = %d\n wsn node num = %d', power, wsnNodeNum));

% plot converage figure
figure();
set(gca,'clipping','on');
for i=1:wsnNodeNum
    PlotCircle(wsnMatrix(i,1),wsnMatrix(i,2),coverageRadius, true);
    plot(wsnMatrix(i,1),wsnMatrix(i,2),'bo','MarkerFaceColor','b');
    axis([0 1 0 1]);
    hold on;
end

title(sprintf('Coverage rate is : %.2f%',100.0*ConverageCalculate(100,100,wsnMatrix,coverageRadius)));



