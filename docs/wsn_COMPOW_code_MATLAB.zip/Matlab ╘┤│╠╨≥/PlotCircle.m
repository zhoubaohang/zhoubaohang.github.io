function [] = PlotCircle(x,y,r,isColored)
    theta=0:0.1:2*pi;  
    Circle1=x+r*cos(theta);  
    Circle2=y+r*sin(theta);  
    plot(Circle1,Circle2,'c','linewidth',1);
    if isColored 
        fill(Circle1, Circle2, 'g');
    end
    axis equal
end