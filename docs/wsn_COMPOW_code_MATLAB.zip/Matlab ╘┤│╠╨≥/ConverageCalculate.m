function [ans] = ConverageCalculate(xrange, yrange, wsn, radius)
    px = 0/xrange:1/xrange:1;
    py = 0/xrange:1/yrange:1;
    sumPoints = (xrange+1)*(yrange+1);
    coveredNums = 0;
    for i=1:size(px,2)
        for j=1:size(py,2)
            for k=1:size(wsn,1)
                if (sqrt((px(i) - wsn(k,1))^2+(py(j) - wsn(k,2))^2) <= radius)
                   coveredNums = coveredNums + 1;
                   break;
                end
            end
        end
    end
    ans = coveredNums / sumPoints;
end