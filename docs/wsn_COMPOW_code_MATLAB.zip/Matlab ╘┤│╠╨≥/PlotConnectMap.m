function [] = PlotConnectMap(wsn, radius)
    rows = size(wsn,1);
    for i = 1:rows
        point1 = wsn(i,:);
        for j = 1:rows
            point2 = wsn(j,:);
            if (point1(1)-point2(1))^2+(point1(2)-point2(2))^2 < radius^2
                plot([point1(1,1) point2(1,1)], [point1(1,2) point2(1,2)],'o-');
                hold on;
            end
        end
    end
end