#ifndef __INTER_H
#define __INTER_H

#include "reg52.h"
#include "lcd.h"
#include "math.h"

#define HPOS	2
#define LPOS	8

extern int volatile set_mode;
extern int volatile high, low;

void ExintInit();

void Exint0(void);

void Exint1(void);

void delay10ms(void);

void SetTempMode(void);

#endif __INTER_H