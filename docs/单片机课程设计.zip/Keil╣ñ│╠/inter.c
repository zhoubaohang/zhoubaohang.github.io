#include "inter.h"

volatile int set_mode = 0;
volatile int high = 0;
volatile int low = 0;

void ExintInit()
{
	IT0=1;  //�жϴ�����ʽΪ�͵�ƽ������IT0=1��Ϊ�±��ش���  
    EX0=1;  //���ⲿ�ж�0  
    IT1=1;
	EX1=1;
	EA=1;
}


void Exint0(void) interrupt 0  
{  	
	if(set_mode == 1)
		high = high + 1;
	if(set_mode == 2)
		low = low + 1;
	if(low > high) low = high;
	delay10ms();
	delay10ms(); 
	SetTempMode();
}

void Exint1(void) interrupt 2  
{  	
	if(set_mode == 1)
		high = high - 1;
	if(set_mode == 2)
		low = low - 1;
	if(high<low) high = low;
	delay10ms();
	delay10ms();
	
	SetTempMode();		 
}

void SetTempMode(void)
{	
	int len = 0;
	
	LcdWriteCom(0x0C);

	DispChar(len++,1,'H');
	DispChar(len++,1,':');
	if(high < 0)
		DispChar(len++,1,'-');
	DispChar(len++, 1, '0'+abs(high));
	DispChar(len++, 1, '`');
	DispChar(len++, 1, 'C');
	DispChar(len++, 1, ' ');
	DispChar(len++, 1, 'L');
	DispChar(len++, 1, ':');
	if(low < 0)
		DispChar(len++,1,'-');
	DispChar(len++, 1, '0'+abs(low));
	DispChar(len++, 1, '`');
	DispChar(len++, 1, 'C');
	DispChar(len, 1, ' ');

	delay10ms();
	delay10ms();
	
	if(set_mode == 1)
		SetCurPosition(HPOS, 1);
	if(set_mode == 2)
		SetCurPosition(LPOS, 1);
	delay10ms();
	delay10ms();
	LcdWriteCom(0x0F);
	delay10ms();
	delay10ms();
}

/*******************************************************************************
* ��������		   : delay10ms()
* ��������       : ʹ��������10ms
* ����           : ��
* ���           : ��
*******************************************************************************/
void delay10ms(void)   //��� 0us
{
    unsigned char a,b,c;
    for(c=1;c>0;c--)
        for(b=38;b>0;b--)
            for(a=130;a>0;a--);
}