#ifndef __TEMP_H_
#define __TEMP_H_

#include <reg52.h>
#include <intrins.h>

sbit DSPORT=P1^7;//P2^2;
extern unsigned char time;


void Delay1ms(unsigned int y);

unsigned char Ds18b20Init();

void Ds18b20WriteByte(unsigned char dat);

unsigned char Ds18b20ReadByte();

void  Ds18b20ChangTemp();

void  Ds18b20ReadTempCom();

int Ds18b20ReadTemp();

void  Read_Temperature(int *tempArr);

#endif
